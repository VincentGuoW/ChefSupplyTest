//for category.js

function urlList(){
        return `https://testcheftest.com/.private2/php/brands.php?`;

}

//for searchbar.js
function urlDocument(){
    
        return "https://testcheftest.com/.private2/php/searchCreator.php";
    
}  

function urlLink(){
        return `https://testcheftest.com/.private2/search.html?`;
    
}

 //products.js, searchResponser.js
function urlPrice(){
        return "https://testcheftest.com/.private2/php/priceReader.php";
}
function  url(){
        return `https://testcheftest.com/.private2/php/searchResponser.php?`;
    
} 
function urlShipping(){
     return `https://testcheftest.com/.private2/php/product.php?`;
}