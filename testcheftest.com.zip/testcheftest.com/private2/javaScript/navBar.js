


function myFunction() {

  var x = document.getElementById("menu");
  
  if (x.className === "menu") {
    x.className = "topnavresponsive";
   
  }
   else {
    x.className = "menu";
  }
}

